import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-contactus',
    templateUrl: 'contact-us.component.html'
})

export class ContactUsComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
    
}